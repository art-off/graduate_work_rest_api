class TodoItem:
    def __init__(self, title):
        self.title = title

    def __repr__(self):
        return f'TodoItem - {self.title}'


class TodoManager:
    def __init__(self):
        self.todo_items = []

    def add_todo(self, todo_item):
        self.todo_items.append(todo_item)



todoManager = TodoManager()

print(todoManager.todo_items)
todoManager.add_todo(TodoItem('lolke'))
print(todoManager.todo_items)